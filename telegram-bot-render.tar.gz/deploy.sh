#!/bin/bash

# Script para fazer deploy no Render
# Uso: ./deploy.sh "mensagem do commit"

if [ -z "$1" ]; then
    MESSAGE="Atualização do bot"
else
    MESSAGE="$1"
fi

echo "📦 Preparando deploy..."

# Verificar se tem mudanças
if [ -z "$(git status --porcelain)" ]; then
    echo "✅ Nenhuma mudança para fazer push"
    exit 0
fi

echo "📝 Commit: $MESSAGE"
git add .
git commit -m "$MESSAGE"

echo "🚀 Push para repositório..."
git push

echo "✅ Deploy iniciado no Render!"
echo "📊 Acompanhe em: https://dashboard.render.com"
